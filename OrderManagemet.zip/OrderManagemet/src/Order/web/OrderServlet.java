package Order.web;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Order.Dao.OrderDAO;
import Order.Model.Order;
/**
 * ControllerServlet.java
 * This servlet acts as a page controller for the application, handling all
 * requests from the order
 *
 */
//Servlets implements class OrderServlets
@WebServlet("/")

public class OrderServlet extends HttpServlet{
	private static final long serialVersionUID=1L;
	private OrderDAO orderDAO;
	
	// see HttpServlet#HttpServlet()
	
	public  OrderServlet() {
		this.orderDAO=new OrderDAO();
		
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest,HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
		this.doGet(request,response);
	}
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
		String action =request.getServletPath();
		try {
		System.out.println(action);
		switch(action) {
		case "/new":
			showNewForm(request,response);
			break;
		case "/insert":
			insertOrder(request, response);
			break;
		case "/delete":
			deleteOrder(request, response);
			break;
		case "/edit":
			showeditForm(request, response);
			break;
		case "/update":
			updateOrder(request, response);
			break;
		default:
			//handle list
			listOrder(request,response);
				break;
		}
	} catch (SQLException ex) {
		throw new ServletException(ex);
	}
	}
	
	private void listOrder(HttpServletRequest request,HttpServletResponse response)
		throws SQLException,IOException,ServletException{
		List<Order> listOrder=orderDAO.selectAllOrder();
		request.setAttribute("listOrder",listOrder);
		RequestDispatcher dispatcher=request.getRequestDispatcher("Order-list.jsp");
		dispatcher.forward(request, response);
	}
	
	private void updateOrder(HttpServletRequest request,HttpServletResponse response)
			throws SQLException, IOException {
		int orderNo=Integer.parseInt(request.getParameter("orderNo"));
		int contactNo=Integer.parseInt(request.getParameter("contactNo"));
		String email=request.getParameter("email");
		String address=request.getParameter("address");
		int quantity=Integer.parseInt(request.getParameter("quantity"));
		float totalAmount=Float.parseFloat(request.getParameter("totalAmount"));
		String orderDate=request.getParameter("orderDate");
		String orderTime=request.getParameter("orderTime");

		Order order=new Order(orderNo,contactNo,email,address,quantity,totalAmount,orderDate,orderTime);
		orderDAO.updateOrder(order);
		response.sendRedirect("list");
	}
	
	private void deleteOrder(HttpServletRequest request,HttpServletResponse response)
			throws SQLException,IOException{
		int orderNo=Integer.parseInt(request.getParameter("orderNo"));
		orderDAO.deleteOrder(orderNo);
		response.sendRedirect("list");
	}
	
	
	private void showeditForm(HttpServletRequest request,HttpServletResponse response)
			throws SQLException, ServletException, IOException{
		int orderNo=Integer.parseInt(request.getParameter("orderNo"));
		Order existingOrder=orderDAO.selectOrder(orderNo);
		RequestDispatcher dispatcher=request.getRequestDispatcher("Order-form.jsp");
		request.setAttribute("order",existingOrder);
		dispatcher.forward(request, response);
	}
	
	
	private void showNewForm(HttpServletRequest request,HttpServletResponse response)
			throws ServletException,IOException{
		RequestDispatcher dispatcher=request.getRequestDispatcher("Order-form.jsp");
		dispatcher.forward(request, response);
	}
	
	private void insertOrder(HttpServletRequest request,HttpServletResponse response)
			throws SQLException,IOException{
		int contactNo=Integer.parseInt(request.getParameter("contactNo"));
		String email=request.getParameter("email");
		String address=request.getParameter("address");
		int quantity=Integer.parseInt(request.getParameter("quantity"));
		float totalAmount=Float.parseFloat(request.getParameter("totalAmount"));
		String orderDate=request.getParameter("orderDate");
		String orderTime=request.getParameter("orderTime");
		Order newOrder=new Order(contactNo,email,address,quantity,totalAmount,orderDate,orderTime);
		orderDAO.insertOrder(newOrder);
		response.sendRedirect("list");
		
}
	}
