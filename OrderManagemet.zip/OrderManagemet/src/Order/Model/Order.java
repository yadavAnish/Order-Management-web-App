package Order.Model;

/**
 * Order.java
 * This is a model class represents a User entity
 *
 */

public class Order {
	private int orderNo;
	private  int contactNo;
	private String email;
	private String address;
	private int quantity;
	private float totalAmount;
	private String orderDate;
	private String orderTime;
	

	//constructor
	
	public int getOrderNo() {
		return orderNo;
	}
	public Order(int orderNo, int contactNo, String email, String address, int quantity, float totalAmount,
			String orderDate, String orderTime) {
		super();
		this.orderNo = orderNo;
		this.contactNo = contactNo;
		this.email = email;
		this.address = address;
		this.quantity = quantity;
		this.totalAmount = totalAmount;
		this.orderDate = orderDate;
		this.orderTime = orderTime; 
		
		
		
		// constructor without orderNo

	}
	public Order(int contactNo, String email, String address, int quantity, float totalAmount, String orderDate,
			String orderTime) {
		super();
		this.contactNo = contactNo;
		this.email = email;
		this.address = address;
		this.quantity = quantity;
		this.totalAmount = totalAmount;
		this.orderDate = orderDate;
		this.orderTime = orderTime;
	}
	
	
	
	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}
	public int getContactNo() {
		return contactNo;
	}
	public void setContactNo(int contactNo) {
		this.contactNo = contactNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public float getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(float totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public String getOrderTime() {
		return orderTime;
	}
	public void setOrderTime(String orderTime) {
		this.orderTime = orderTime;
	}






}
