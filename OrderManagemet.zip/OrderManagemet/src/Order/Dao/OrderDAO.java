package Order.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Order.Model.Order;

// This DAO class provides CRUDE database operations for the table order in the database 
public class OrderDAO {
	private String jdbcURL="jdbc:mysql://localhost:3306/store_db?useSSL=false";
	private String jdbcUsername="root";
	private String jdbcPassword="root";
	
	private static final String INSERT_INTO_SQL="INSERT INTO order_detail"+"(contactNo,email,address,quantity,totalAmount,orderDate,orderTime) VALUES"+"(?,?,?,?,?,?,?)";
	
	private static final String SELECT_ORDER_BY_NO="select orderNo,contactNo,email,address,quantity,totalAmount,orderDate,orderTime from order_detail where orderNo=?";
	private static final String SELECT_ALL_ORDER="select * from order_detail";
	private static final String DELETE_ORDER_SQL="delete from order_detail where orderNo=?";
	private static final String UPDATE_USER_SQL="update order_detail set contactNo=?,email=?,address=?,quantity=?,totalAmount=?,orderDate=?,orderTime=? where orderNo=?";
	
	
	
	protected Connection getConnection() {
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection(jdbcURL,jdbcUsername,jdbcPassword);
		}catch (SQLException e) {
			e.printStackTrace();
			}catch(ClassNotFoundException e) {
				e.printStackTrace();
			}
		return connection;
	}
	
	//create or insert order
	
	public void insertOrder(Order order) throws SQLException {
		try(Connection connection=getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement(INSERT_INTO_SQL)){
			preparedStatement.setInt(1,order.getContactNo());
			preparedStatement.setString(2,order.getEmail());
			preparedStatement.setString(3,order.getAddress());
			preparedStatement.setInt(4,order.getQuantity());
			preparedStatement.setFloat(5,order.getTotalAmount());
			preparedStatement.setString(6,order.getOrderDate());
			preparedStatement.setString(7,order.getOrderTime());
			preparedStatement.executeUpdate();
		}catch (SQLException e) {
			printSQLException(e);
		}
				
		
		
	}
		//update user
	
	public boolean updateOrder(Order order) throws SQLException{
		boolean rowUpdated;
		try(Connection connection=getConnection();
				PreparedStatement Statement=connection.prepareStatement(UPDATE_USER_SQL);){
			Statement.setInt(1,order.getContactNo());
			Statement.setString(2,order.getEmail());
			Statement.setString(3,order.getAddress());
			Statement.setInt(4,order.getQuantity());
			Statement.setFloat(5,order.getTotalAmount());
			Statement.setString(6,order.getOrderDate());
			Statement.setString(7,order.getOrderTime());
			Statement.setInt(8,order.getOrderNo());
			
			rowUpdated=Statement.executeUpdate()>0;
		}
		return rowUpdated;
			
		}
		
	
		//select user by Id

public Order selectOrder(int orderNo) {
	Order order=null;
	//establishing conn
	try(Connection connection=getConnection();
			//step2 Create a statement using conn object
			PreparedStatement preparedStatement=connection.prepareStatement(SELECT_ORDER_BY_NO);){
		preparedStatement.setInt(1, orderNo);
		System.out.println(preparedStatement);
		//step3: execute the query or update the query
		ResultSet rs=preparedStatement.executeQuery();
		//step4 process the resultset object
		while(rs.next()) {
			int contactNo=rs.getInt("contactNo");
			String email=rs.getString("email");
			String address=rs.getString("address");
			int quantity=rs.getInt("quantity");
			float totalAmount=rs.getFloat( "totalAmount");
			String orderDate=rs.getString("orderDate");
			String orderTime=rs.getString("orderTime");
			order =new Order(orderNo,contactNo,email,address,quantity,totalAmount,orderDate,orderTime);
		}
		}catch(SQLException e) {
			printSQLException(e);
		
	}
	return order;
			
			
	
}
	
		//select user


public List<Order> selectAllOrder() {
	List<Order> orders=new ArrayList<>();
	//establishing conn
	try(Connection connection=getConnection();
			//step2 Create a statement using conn object
			PreparedStatement preparedStatement=connection.prepareStatement(SELECT_ALL_ORDER);){
		//preparedStatement.setInt(1, orderNo);
		System.out.println(preparedStatement);
		//step3: execute the query or update the query
		ResultSet rs=preparedStatement.executeQuery();
		//step4 process the resultset object
		while(rs.next()) {
			int orderNo=rs.getInt("orderNo");
			int contactNo=rs.getInt("contactNo");
			String email=rs.getString("email");
			String address=rs.getString("address");
			int quantity=rs.getInt("quantity");
			float totalAmount=rs.getFloat( "totalAmount");
			String orderDate=rs.getString("orderDate");
			String orderTime=rs.getString("orderTime");
			orders.add (new Order(orderNo,contactNo,email,address,quantity,totalAmount,orderDate,orderTime));
			System.out.println("Row from db");
		}
		}catch(SQLException e) {
			printSQLException(e);
		
	}
	return orders;
			
			
	
}

		//delete order
public boolean deleteOrder(int orderNo) throws SQLException{
	boolean rowDeleted;
	try(Connection connection=getConnection();
			PreparedStatement statement=connection.prepareStatement(DELETE_ORDER_SQL);){
				statement.setInt(1, orderNo);
				rowDeleted=statement.executeUpdate()>0;
			}
			return rowDeleted;
		}

private void printSQLException(SQLException ex) {
	for (Throwable e : ex) {
		if (e instanceof SQLException) {
			e.printStackTrace(System.err);
			System.err.println("SQLState: " + ((SQLException) e).getSQLState());
			System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
			System.err.println("Message: " + e.getMessage());
			Throwable t = ex.getCause();
			while (t != null) {
				System.out.println("Cause: " + t);
				t = t.getCause();
			}
		}
	}
}

}
